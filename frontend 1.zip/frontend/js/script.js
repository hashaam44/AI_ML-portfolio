/* =========================
   THEME
========================= */

const themeToggle = document.getElementById("themeToggle");
const themeIcon = document.getElementById("themeIcon");

const savedTheme = localStorage.getItem("theme");

if (savedTheme) {
    document.documentElement.setAttribute("data-theme", savedTheme);
}

updateThemeIcon();


themeToggle.addEventListener("click", () => {

    const currentTheme =
        document.documentElement.getAttribute("data-theme");

    const newTheme =
        currentTheme === "dark" ? "light" : "dark";

    document.documentElement.setAttribute(
        "data-theme",
        newTheme
    );

    localStorage.setItem("theme", newTheme);

    updateThemeIcon();
});


function updateThemeIcon() {

    const currentTheme =
        document.documentElement.getAttribute("data-theme");

    if (currentTheme === "dark") {
        themeIcon.textContent = "☀";
    } else {
        themeIcon.textContent = "☾";
    }
}


/* =========================
   MOBILE MENU
========================= */

const menuToggle =
    document.getElementById("menuToggle");

const navLinks =
    document.getElementById("navLinks");


menuToggle.addEventListener("click", () => {

    navLinks.classList.toggle("show");

});


document.querySelectorAll(".nav-links a").forEach(link => {

    link.addEventListener("click", () => {

        navLinks.classList.remove("show");

    });

});


/* =========================
   PROJECT SEARCH
========================= */

const searchInput =
    document.getElementById("projectSearch");

const projectCards =
    document.querySelectorAll(".project-card");

const noResults =
    document.getElementById("noResults");


searchInput.addEventListener("input", () => {

    const searchTerm =
        searchInput.value.toLowerCase().trim();

    let visibleProjects = 0;

    projectCards.forEach(card => {

        const searchableText =
            card.dataset.search.toLowerCase();

        if (searchableText.includes(searchTerm)) {

            card.style.display = "";

            visibleProjects++;

        } else {

            card.style.display = "none";

        }

    });


    if (visibleProjects === 0) {

        noResults.style.display = "block";

    } else {

        noResults.style.display = "none";

    }

});


/* =========================
   PROJECT FILTER
========================= */

const filterButtons =
    document.querySelectorAll(".filter-btn");


filterButtons.forEach(button => {

    button.addEventListener("click", () => {

        filterButtons.forEach(btn => {
            btn.classList.remove("active");
        });

        button.classList.add("active");

        const selectedFilter =
            button.dataset.filter;

        let visibleProjects = 0;


        projectCards.forEach(card => {

            const categories =
                card.dataset.category;

            if (
                selectedFilter === "all" ||
                categories.includes(selectedFilter)
            ) {

                card.style.display = "";

                visibleProjects++;

            } else {

                card.style.display = "none";

            }

        });


        if (visibleProjects === 0) {

            noResults.style.display = "block";

        } else {

            noResults.style.display = "none";

        }

    });

});


/* =========================
   CONTACT FORM
========================= */
const contactForm = document.querySelector("#contactForm");

if (contactForm) {

    contactForm.addEventListener("submit", async (e) => {

        e.preventDefault();

        const name = document.querySelector("#name").value;
        const email = document.querySelector("#email").value;
        const subject = document.querySelector("#subject").value;
        const message = document.querySelector("#message").value;


        try {

            const response = await fetch(
                "http://127.0.0.1:8000/contact",
                {
                    method: "POST",

                    headers: {
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify({
                        name: name,
                        email: email,
                        subject: subject,
                        message: message
                    })
                }
            );


            const data = await response.json();


            if (response.ok) {

                alert(data.message);

                contactForm.reset();

            } else {

                alert("Something went wrong.");

            }


        } catch (error) {

            console.error(error);

            alert(
                "Could not connect to the backend."
            );

        }

    });

}